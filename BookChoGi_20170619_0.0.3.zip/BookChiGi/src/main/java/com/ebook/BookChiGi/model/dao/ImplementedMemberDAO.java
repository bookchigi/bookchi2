package com.ebook.BookChiGi.model.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ebook.BookChiGi.model.dto.MemberVO;

public class ImplementedMemberDAO implements MemberDAO {
	private SqlSession ss;
	
	public void setSqlSession (SqlSession ss) { this.ss = ss; }
	
	@Override public List<MemberVO> searchMemberAll () throws SQLException {
		return null;
	}

	@Override public MemberVO searchMemberByNum (int userNo) throws SQLException {
		return null;
	}

	@Override
	public MemberVO searchMemberByMail (String userMail) throws SQLException {
		return null;
	}

	@Override
	public MemberVO searchMemberByName (String userName) throws SQLException {
		return null;
	}
	
	@Override
	public boolean isMemberByMail(String userMail) throws SQLException {
		return false;
	}

	@Override
	public int signupMember (MemberVO member) throws SQLException {
		if (member.getUserGender().equals ("man")) member.setUserGender ("��");
		if (member.getUserGender().equals ("woman")) member.setUserGender ("��");
		
		member.setUserPhone (member.getUserPhone().substring(0, 3) + "-"
				+ member.getUserPhone().substring(3, 7) + "-"
				+ member.getUserPhone().substring(7, 11));
		
		try { return ss.insert ("signup", member); }
		catch (Exception e) { return 0; }
	}

	@Override
	public int modifyMember (MemberVO member) throws SQLException {
		return 0;
	}

	@Override
	public int removeMember (int userNo) throws SQLException {
		return 0;
	}
}