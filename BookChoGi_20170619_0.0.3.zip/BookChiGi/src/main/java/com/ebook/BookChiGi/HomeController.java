package com.ebook.BookChiGi;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ebook.BookChiGi.model.dao.MemberDAO;
import com.ebook.BookChiGi.model.dto.MemberVO;

@Controller
public class HomeController {
	private MemberDAO dao;
	
	@Autowired
	public void setDao (MemberDAO dao) { this.dao = dao; }
	
	@RequestMapping ("/") public String home () { return "home"; }
	@RequestMapping ("/login") public String login () { return "login"; }
	@RequestMapping (value="/signup", method=RequestMethod.GET) public String signup () { return "signup"; }
	
	@RequestMapping (value="/signup", method=RequestMethod.POST)
	public String signup (@ModelAttribute MemberVO member, ModelAndView mav) {
		System.out.println (member.toString ());
		int result = 0;
		Exception exception = null;
		
		try {
			result = dao.signupMember (member);
		} catch (SQLException e) { e.printStackTrace (); }
		
		if (result != 0) return "signupok";
		else {
			mav.addObject ("signupErr", "<div class='alert alert-danger' role='alert'>������ �߻��Ͽ����ϴ�. �ٽ� �ѹ� �õ����ּ���.</div>");
			
			return "redirect:signup";
		}
	}
}