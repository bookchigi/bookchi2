package com.ebook.BookChiGi.model.dao;

import java.util.List;

import com.ebook.BookChiGi.model.dto.MemberVO;

public interface MemberDAO {
	public List<MemberVO> searchMemberAll ();
	public MemberVO searchMemberByNum (int userNo);
	public MemberVO searchMemberByMail (String userMail);
	public MemberVO searchMemberByName (String userName);
	public boolean isMemberByMail (String userMail);
	public int signupMember (MemberVO member);
	public int modifyMember (MemberVO member);
	public int removeMember (int userNo);
}