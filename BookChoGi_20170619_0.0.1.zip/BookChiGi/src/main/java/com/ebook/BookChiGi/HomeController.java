package com.ebook.BookChiGi;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ebook.BookChiGi.model.dao.MemberDAO;
import com.ebook.BookChiGi.model.dto.MemberVO;

@Controller
public class HomeController {
	private MemberDAO dao;
	public void setDao (MemberDAO dao) { this.dao = dao; }
	
	@RequestMapping ("/") public String home () { return "home"; }
	@RequestMapping ("/login") public String login () { return "login"; }
	@RequestMapping ("/signup") public String signup () { return "signup"; }
	
	@RequestMapping (value="/signupSubmit", method=RequestMethod.POST)
	public String signupSubmit (@ModelAttribute MemberVO member, ModelAndView mav) {
		System.out.println (member.toString ());
		
		int result = dao.signupMember (member);
		
		if (result != 0) return "signupok";
		else {
			mav.addObject ("signupErr", "<div class='alert alert-danger' role='alert'>${signErr }</div>");
			
			return "redirect:signup";
		}
	}
}