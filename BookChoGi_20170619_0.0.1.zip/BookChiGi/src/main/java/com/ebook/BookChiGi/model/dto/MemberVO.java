package com.ebook.BookChiGi.model.dto;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MemberVO {
	private int userNo;
	private String userMail;
	private String userPw;
	private String userName;
	private String userPhone;
	private String userGender;
	private Date userBirth;
	private Date userSignDay;
	private int userState;
	
	public MemberVO () {}
	public MemberVO (ResultSet rset) throws SQLException {
		this.userNo = rset.getInt ("userNo");
		this.userMail = rset.getString ("userMail");
		this.userPw = rset.getString ("userPw");
		this.userName = rset.getString ("userName");
		this.userPhone = rset.getString ("userPhone");
		this.userGender = rset.getString ("userGender");
		this.userBirth = rset.getDate ("userDate");
		this.userSignDay = rset.getDate ("userSignDay");
		this.userState = rset.getInt ("userState");
	}
	
	public int getUserNo () { return userNo; }
	public String getUserMail () { return userMail; }
	public String getUserPw () { return userPw; }
	public String getUserName () { return userName; }
	public String getUserPhone () { return userPhone; }
	public String getUserGender () { return userGender; }
	public Date getUserBirth () { return userBirth; }
	public Date getUserSignDay () { return userSignDay; }
	public int getUserState () { return userState; }
	
	public void setUserNo (int userNo) { this.userNo = userNo; }
	public void setUserMail (String userMail) { this.userMail = userMail; }
	public void setUserPw (String userPw) { this.userPw = userPw; }
	public void setUserName (String userName) { this.userName = userName; }
	public void setUserPhone (String userPhone) { this.userPhone = userPhone; }
	public void setUserGender (String userGender) { this.userGender = userGender; }
	public void setUserBirth (Date userBirth) { this.userBirth = userBirth; }
	public void setUserSignDay (Date userSignDay) { this.userSignDay = userSignDay; }
	public void setUserState (int userState) { this.userState = userState; }
	
	@Override
	public String toString () {
		return "MemberVO [userNo = " + userNo + ", userMail = " + userMail + ", userPw = " + userPw + ", userName = " + userName
				+ ", userPhone = " + userPhone + ", userGender = " + userGender + ", userBirth = " + userBirth
				+ ", userSignDay = " + userSignDay + ", userState = " + userState + "]";
	}
}