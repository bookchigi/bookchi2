package com.ebook.BookChiGi.model.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ebook.BookChiGi.model.dto.MemberVO;

public class ImplementedMemberDAO implements MemberDAO {
	private SqlSession ss;
	
	public void setSqlSession (SqlSession ss) { this.ss = ss; }
	
	@Override public List<MemberVO> searchMemberAll () {
		return null;
	}

	@Override public MemberVO searchMemberByNum (int userNo) {
		return null;
	}

	@Override
	public MemberVO searchMemberByMail (String userMail) {
		return null;
	}

	@Override
	public MemberVO searchMemberByName (String userName) {
		return null;
	}
	
	@Override
	public boolean isMemberByMail(String userMail) {
		return false;
	}

	@Override
	public int signupMember (MemberVO member) {
		return ss.insert ("signup", member);
	}

	@Override
	public int modifyMember (MemberVO member) {
		return 0;
	}

	@Override
	public int removeMember (int userNo) {
		return 0;
	}
}