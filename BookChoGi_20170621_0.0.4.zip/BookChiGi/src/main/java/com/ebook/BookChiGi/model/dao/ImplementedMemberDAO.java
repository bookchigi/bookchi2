package com.ebook.BookChiGi.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;

import com.ebook.BookChiGi.model.dto.MemberVO;

public class ImplementedMemberDAO implements MemberDAO {
	@Autowired
	private DataSource ds = null;
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rset = null;
	
	private void closeAll () throws SQLException {
		if (rset != null) rset.close ();
		if (pstmt != null) pstmt.close ();
		if (conn != null) conn.close ();
	}
	
	@Override public List<MemberVO> searchMemberAll () throws SQLException {
		return null;
	}

	@Override public MemberVO searchMemberByNum (int userNo) throws SQLException {
		return null;
	}

	@Override
	public MemberVO searchMemberByMail (String userMail) throws SQLException {
		return null;
	}

	@Override
	public MemberVO searchMemberByName (String userName) throws SQLException {
		return null;
	}
	
	@Override
	public boolean isMemberByMail (String userMail) throws SQLException {
		try {
			conn = ds.getConnection ();
			pstmt = conn.prepareStatement ("select * from BookChiGi_member where userMail = ?");
			pstmt.setString (1, userMail);
			rset = pstmt.executeQuery ();
			
			return rset.next ();
		} catch (Exception e) { e.printStackTrace ();
		} finally { closeAll (); }
		
		return false;
	}

	@Override
	public int signupMember (MemberVO member) throws SQLException {
		int resultCode = 0;
		
		try {
			System.out.println ("Duplicated Check : " + isMemberByMail (member.getUserMail ()));
			if (!isMemberByMail (member.getUserMail ())) {
				conn = ds.getConnection ();
				pstmt = conn.prepareStatement ("insert into BookChiGi_member values (member_seq.nextval, ?, ?, ?, ?, ?, ?, sysdate, 2)");
				pstmt.setString (1, member.getUserMail ());
				pstmt.setString (2, member.getUserPw ());
				pstmt.setString (3, member.getUserName ());
				pstmt.setString (4, member.getUserPhone ().substring(0, 3) + "-"
						+ member.getUserPhone().substring(3, 7) + "-"
						+ member.getUserPhone().substring(7, 10));
				pstmt.setString (5, member.getUserGender () == "man"? "��" : "��");
				pstmt.setDate (6, member.getUserBirth ());
				return pstmt.executeUpdate ();
			} else resultCode = -1;
		} catch (Exception e) { e.printStackTrace ();
		} finally { closeAll (); }
		
		return resultCode;
	}

	@Override
	public int modifyMember (MemberVO member) throws SQLException {
		return 0;
	}

	@Override
	public int removeMember (int userNo) throws SQLException {
		return 0;
	}
}