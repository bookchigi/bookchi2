package com.ebook.BookChiGi.model.dao;

import java.sql.SQLException;
import java.util.List;

import com.ebook.BookChiGi.model.dto.BookVO;

public interface BookDAO {
	List<BookVO> alignBookByNew () throws SQLException;
	List<BookVO> alignBookByPop () throws SQLException;
	List<BookVO> alignBookByRec () throws SQLException;
	List<BookVO> alignBookBySec () throws SQLException;
}