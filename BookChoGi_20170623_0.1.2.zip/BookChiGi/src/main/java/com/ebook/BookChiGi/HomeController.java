package com.ebook.BookChiGi;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ebook.BookChiGi.model.dao.BookDAO;
import com.ebook.BookChiGi.model.dao.MemberDAO;
import com.ebook.BookChiGi.model.dto.MemberVO;

@Controller
public class HomeController {
	private MemberDAO memberDao;
	private BookDAO bookDao;
	
	@Autowired public void setMemberDao (MemberDAO memberDao) { this.memberDao = memberDao; }
	@Autowired public void setBookDao (BookDAO bookDao) { this.bookDao = bookDao; }
	
	@RequestMapping ("/") public String home (Model model) {
		try { model.addAttribute ("booklist_new", bookDao.alignBookByNew ()); } catch (SQLException e) { e.printStackTrace (); }
		try { model.addAttribute ("booklist_pop", bookDao.alignBookByPop ()); } catch (SQLException e) { e.printStackTrace (); }
		try { model.addAttribute ("booklist_rec", bookDao.alignBookByRec ()); } catch (SQLException e) { e.printStackTrace (); }
		try { model.addAttribute ("booklist_sec", bookDao.alignBookBySec ()); } catch (SQLException e) { e.printStackTrace (); }
		
		return "home";
	}
	
	@RequestMapping (value="/login", method=RequestMethod.GET) public String login () { return "login"; }
	
	@RequestMapping (value="/login", method=RequestMethod.POST) public ModelAndView login (HttpServletRequest request, Model model) {
		ModelAndView mav = new ModelAndView ();
		
		try {
			System.out.println (memberDao.isLoginPassed (request.getParameter ("userMail"), request.getParameter ("userPw")));
			if (memberDao.isLoginPassed (request.getParameter ("userMail"), request.getParameter ("userPw"))) {
				model.addAttribute ("account", memberDao.searchMemberByMail (request.getParameter ("userMail")));
				mav.addObject ("account", memberDao.searchMemberByMail (request.getParameter ("userMail")));
				mav.setViewName ("home");
				return mav;
			} else {
				model.addAttribute ("loginErr", "<div class='alert alert-danger' role='alert'>�α��� ������ �������� �ʽ��ϴ�.</div>");
				mav.setViewName ("redirect:login");
				return mav;
			}
		} catch (Exception e) {
			e.printStackTrace ();
			mav.addObject ("loginErr", "<div class='alert alert-danger' role='alert'>��� ������ �߻��� �� �����ϴ�. �ٽ� �õ����ּ���.</div>");
			mav.setViewName ("redirect:login");
			return mav;
		}
	}
	
	@RequestMapping (value="/signup", method=RequestMethod.GET) public String signup () { return "signup"; }
	
	@RequestMapping (value="/signup", method=RequestMethod.POST) public String signup (@ModelAttribute MemberVO member, Model model) {
		int result = 0;
		String errMsg = "";

		if (!member.getUserPw().equals (member.getRepeatPw ())) {
			errMsg = "��Ͽ� �����߽��ϴ�. �н����� Ȯ���� ��ġ���� �ʽ��ϴ�.";
			model.addAttribute ("signupErr", "<div class='alert alert-danger' role='alert'>" + errMsg + "</div>");
			System.out.println (errMsg);
			return "redirect:signup";
		}
		
		try {
			result = memberDao.signupMember (member);
		} catch (SQLException e) { e.printStackTrace (); }
		
		if (result == 1) return "signupok";
		else {
			switch (result) {
				case -1 : errMsg = "��Ͽ� �����߽��ϴ�. �� ������ �ݺ��� ��� �����ּ� �ߺ��� ���ɼ��� �����ϴ�."; break;
				case  0 : errMsg = "��Ͽ� �����߽��ϴ�. �� ������ �ݺ��� ��� �����ڿ��� �����Ͽ��ּ���."; break;
				default : break;
			}
			
			System.out.println (errMsg);
			model.addAttribute ("signupErr", "<div class='alert alert-danger' role='alert'>" + errMsg + "</div>");
			
			return "redirect:signup";
		}
	}
}