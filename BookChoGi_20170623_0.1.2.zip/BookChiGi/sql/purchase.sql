DROP SEQUENCE purchase_seq;
CREATE SEQUENCE purchase_seq
start with 0
increment by 1 minvalue 0
maxvalue 999999 nocycle;

drop table Bookchigi_purchase;
create table Bookchigi_purchase(
	purchase_seq number primary key,
	userMail varchar2(40) not null,
    goods_num number not null,
	p_book_price number,
	constraint fk_user foreign key(userMail) references Bookchigi_member(userMail)
);

insert into Bookchigi_purchase values (purchase_seq.NEXTVAL, 'aa@aa.aa', 1, 18000);

select * from Bookchigi_purchase;