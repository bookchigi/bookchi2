DROP SEQUENCE book_isbn_seq;
CREATE SEQUENCE book_isbn_seq
START WITH 1
INCREMENT BY 1
MAXVALUE 999999 nocycle;

drop table Bookchigi_book_info;
create table BookChiGi_book_info(
	book_isbn_seq   number      	not null,
	book_name  		varchar2(100)	not null,
	book_price  	number			not null,
	book_type  		varchar2(100),
	book_athor 		varchar2(100),
	book_publisher  varchar2(100),
	book_release	date,
	book_page		number,
	book_contents	varchar2(1024),
    book_cover      varchar2(1024),
	constraint pk_book_isbn	primary key (book_isbn_seq)
);

insert into Bookchigi_book_info values (book_isbn_seq.NEXTVAL, '�ﱹ��', 20000, '�Ҽ�', '�̹���', '������', to_date('03-10-2002','mm-dd-yyyy'), 500, 'content', 'resources/Book/book_009.jpg');

select * from Bookchigi_book_info;