package com.ebook.BookChiGi.model.dto;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DiscountVO {
	private int discount_no;
	private String discount_name;
	private String discount_content;
	private int discount_target;
	private int discount_price;
	private int discount_percent;
	private Date discount_start;
	private Date discount_end;
	
	public DiscountVO () {}
	public DiscountVO (int discount_no, String discount_name, String  discount_content, int discount_target,
			int discount_price, int discount_percent, Date discount_start, Date discount_end) {
		this.discount_no = discount_no;
		this.discount_name = discount_name;
		this.discount_content = discount_content;
		this.discount_target = discount_target;
		this.discount_price = discount_price;
		this.discount_percent = discount_percent;
		this.discount_start = discount_start;
		this.discount_end = discount_end;
	}
	public DiscountVO (ResultSet rset) throws SQLException {
		this.discount_no = rset.getInt ("discount_no");
		this.discount_name = rset.getString ("discount_name");
		this.discount_content = rset.getString ("discount_content");
		this.discount_target = rset.getInt ("discount_target");
		this.discount_price = rset.getInt ("discount_price");
		this.discount_percent = rset.getInt ("discount_percent");
		this.discount_start = rset.getDate ("discount_start");
		this.discount_end = rset.getDate ("discount_end");
	}
	
	public int getDiscount_no () { return discount_no; }
	public String getDiscount_name () { return discount_name; }
	public String getDiscount_content () { return discount_content; }
	public int getDiscount_target () { return discount_target; }
	public int getDiscount_price () { return discount_price; }
	public int getDiscount_percent () { return discount_percent; }
	public Date getDiscount_start () { return discount_start; }
	public Date getDiscount_end () { return discount_end; }
	
	public void setDiscount_no (int discount_no) { this.discount_no = discount_no; }
	public void setDiscount_name (String discount_name) { this.discount_name = discount_name; }
	public void setDiscount_content (String discount_content) { this.discount_content = discount_content; }
	public void setDiscount_target (int discount_target) { this.discount_target = discount_target; }
	public void setDiscount_price (int discount_price) { this.discount_price = discount_price; }
	public void setDiscount_percentage (int discount_percent) { this.discount_percent = discount_percent; }
	public void setDiscount_start (Date discount_start) { this.discount_start = discount_start; }
	public void setDiscount_end (Date discount_end) { this.discount_end = discount_end; }
	
	@Override
	public String toString () {
		return "DiscountVO [discount_no=" + discount_no + ", discount_name=" + discount_name + ", discount_content="
				+ discount_content + ", discount_target=" + discount_target + ", discount_price=" + discount_price
				+ ", discount_percent=" + discount_percent + ", discount_start=" + discount_start
				+ ", discount_end=" + discount_end + "]";
	}
}