package com.ebook.BookChiGi.model.dto;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TalkaboutVO {
	private int talkaboutNo;
	private String talkaboutWriter;
	private String talkaboutTitle;
	private String talkaboutContent;
	private Date talkaboutDate;
	private int talkaboutViewcount;
	private int talkaboutReference;

	public TalkaboutVO () {}
	public TalkaboutVO (int talkaboutNo, String talkaboutWriter, String talkaboutTitle, String talkaboutContent,
			Date talkaboutDate, int talkaboutViewcount, int talkaboutReference) {
		this.talkaboutNo = talkaboutNo;
		this.talkaboutWriter = talkaboutWriter;
		this.talkaboutTitle = talkaboutTitle;
		this.talkaboutContent = talkaboutContent;
		this.talkaboutDate = talkaboutDate;
		this.talkaboutViewcount = talkaboutViewcount;
		this.talkaboutReference = talkaboutReference;
	}
	public TalkaboutVO (ResultSet rset) throws SQLException {
		this.talkaboutNo = rset.getInt ("bbs_no");
		this.talkaboutWriter = rset.getString ("bbs_writer");
		this.talkaboutTitle = rset.getString ("bbs_title");
		this.talkaboutContent = rset.getString ("bbs_content");
		this.talkaboutDate = rset.getDate ("bbs_date");
		this.talkaboutViewcount = rset.getInt ("bbs_viewcount");
		this.talkaboutReference = rset.getInt ("bbs_reference");
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((talkaboutContent == null) ? 0 : talkaboutContent.hashCode());
		result = prime * result + ((talkaboutDate == null) ? 0 : talkaboutDate.hashCode());
		result = prime * result + talkaboutNo;
		result = prime * result + talkaboutReference;
		result = prime * result + ((talkaboutTitle == null) ? 0 : talkaboutTitle.hashCode());
		result = prime * result + talkaboutViewcount;
		result = prime * result + ((talkaboutWriter == null) ? 0 : talkaboutWriter.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass () != obj.getClass ()) return false;
		TalkaboutVO other = (TalkaboutVO) obj;
		if (talkaboutContent == null) {
			if (other.talkaboutContent != null) return false;
		} else if (!talkaboutContent.equals(other.talkaboutContent)) return false;
		if (talkaboutDate == null) {
			if (other.talkaboutDate != null) return false;
		} else if (!talkaboutDate.equals(other.talkaboutDate)) return false;
		if (talkaboutNo != other.talkaboutNo) return false;
		if (talkaboutReference != other.talkaboutReference) return false;
		if (talkaboutTitle == null) {
			if (other.talkaboutTitle != null) return false;
		} else if (!talkaboutTitle.equals(other.talkaboutTitle)) return false;
		if (talkaboutViewcount != other.talkaboutViewcount) return false;
		if (talkaboutWriter == null) {
			if (other.talkaboutWriter != null) return false;
		} else if (!talkaboutWriter.equals(other.talkaboutWriter)) return false;
		
		return true;
	}
	
	public int getTalkaboutNo () { return talkaboutNo; }
	public String getTalkaboutWriter () { return talkaboutWriter; }
	public String getTalkaboutTitle () { return talkaboutTitle; }
	public String getTalkaboutContent () { return talkaboutContent; }
	public Date getTalkaboutDate () { return talkaboutDate; }
	public int getTalkaboutViewcount () { return talkaboutViewcount; }
	public int getTalkaboutReference () { return talkaboutReference; }
	
	public void setTalkaboutNo (int talkaboutNo) { this.talkaboutNo = talkaboutNo; }
	public void setTalkaboutWriter (String talkaboutWriter) { this.talkaboutWriter = talkaboutWriter; }
	public void setTalkaboutTitle (String talkaboutTitle) { this.talkaboutTitle = talkaboutTitle; }
	public void setTalkaboutContent (String talkaboutContent) { this.talkaboutContent = talkaboutContent; }
	public void setTalkaboutDate (Date talkaboutDate) { this.talkaboutDate = talkaboutDate; }
	public void setTalkaboutViewcount (int talkaboutViewcount) { this.talkaboutViewcount = talkaboutViewcount; }
	public void setTalkaboutReference (int talkaboutReference) { this.talkaboutReference = talkaboutReference; }
	
	@Override
	public String toString () {
		return "TalkaboutVO [talkaboutNo=" + talkaboutNo + ", talkaboutWriter=" + talkaboutWriter + ", talkaboutTitle="
				+ talkaboutTitle + ", talkaboutContent=" + talkaboutContent + ", talkaboutDate=" + talkaboutDate
				+ ", talkaboutViewcount=" + talkaboutViewcount + ", talkaboutReference=" + talkaboutReference + "]";
	}
}