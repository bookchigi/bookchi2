package com.ebook.BookChiGi.model.dto;

import java.sql.Date;

public class PurchaseVO {
	private int purchase_no;
	private String purchase_buyer;
	private int purchase_bookno;
	private int purchase_price;
	private Date purchase_date;
	private int purchase_discountno;
	
	public PurchaseVO () {}
	public PurchaseVO (int purchase_no, String purchase_buyer, int purchase_bookno, int purchase_price, Date purchase_date, int purchase_discountno) {
		this.purchase_no = purchase_no;
		this.purchase_buyer = purchase_buyer;
		this.purchase_bookno = purchase_bookno;
		this.purchase_price = purchase_price;
		this.purchase_date = purchase_date;
		this.purchase_discountno = purchase_discountno;
	}
	
	public int getPurchase_no () { return purchase_no; }
	public String getPurchase_buyer () { return purchase_buyer; }
	public int getPurchase_bookno () { return purchase_bookno; }
	public int getPurchase_price () { return purchase_price; }
	public Date getPurchase_date () { return purchase_date; }
	public int getPurchase_discountno () { return purchase_discountno; }
	
	public void setPurchase_no (int purchase_no) { this.purchase_no = purchase_no;}
	public void setPurchase_buyer (String purchase_buyer) { this.purchase_buyer = purchase_buyer; }
	public void setPurchase_bookno (int purchase_bookno) { this.purchase_bookno = purchase_bookno; }
	public void setPurchase_price (int purchase_price) { this.purchase_price = purchase_price; }
	public void setPurchase_date (Date purchase_date) { this.purchase_date = purchase_date; }
	public void setPurchase_discountno (int purchase_discountno) { this.purchase_discountno = purchase_discountno; }
	
	@Override
	public String toString () {
		return "PurchaseVO [purchase_no=" + purchase_no + ", purchase_buyer=" + purchase_buyer + ", purchase_bookno="
				+ purchase_bookno + ", purchase_price=" + purchase_price + ", purchase_date=" + purchase_date
				+ ", purchase_discountno=" + purchase_discountno + "]";
	}
}