package com.ebook.BookChiGi.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;

import com.ebook.BookChiGi.model.dto.TalkaboutVO;

public class ImplementedTalkaboutDAO implements TalkaboutDAO {
	@Autowired
	private DataSource ds = null;
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rset = null;
	
	private void closeAll () throws SQLException {
		if (rset != null) rset.close ();
		if (pstmt != null) pstmt.close ();
		if (conn != null) conn.close ();
	}

	@Override
	public int boardWrite (TalkaboutVO talkaboutVO) throws SQLException {
		try {
			conn = ds.getConnection ();
			pstmt = conn.prepareStatement ("insert into bookchigi_bbs values (bbs_seq.nextval, ?, ?, ?, sysdate, 0, -1)");
			pstmt.setString (1, talkaboutVO.getTalkaboutWriter ());
			pstmt.setString (2, talkaboutVO.getTalkaboutTitle ());
			pstmt.setString (3, talkaboutVO.getTalkaboutContent ());
			
			return pstmt.executeUpdate ();
		} catch (Exception e) { e.printStackTrace ();
		} finally { closeAll (); }
		
		return 0;
	}

	@Override
	public int boardUpdate (TalkaboutVO talkaboutVO) throws SQLException {
		try {
			conn = ds.getConnection ();
			pstmt = conn.prepareStatement ("update bookchigi_bbs set bbs_writer = ?, bbs_title = ?, bbs_content = ? where bbs_no = ? and bbs_viewcount > -1");
			pstmt.setString (1, talkaboutVO.getTalkaboutWriter ());
			pstmt.setString (2, talkaboutVO.getTalkaboutTitle ());
			pstmt.setString (3, talkaboutVO.getTalkaboutContent ());
			pstmt.setInt (4, talkaboutVO.getTalkaboutNo ());
			return pstmt.executeUpdate ();
		} catch (Exception e) { e.printStackTrace ();
		} finally { closeAll (); }
		
		return 0;
	}

	@Override
	public int boardDelete (int no) throws SQLException {
		try {
			conn = ds.getConnection ();
			pstmt = conn.prepareStatement ("delete from bookchigi where bbs_no = ? and bbs_viewcount > -1");
			pstmt.setInt (1, no);
			return pstmt.executeUpdate ();
		} catch (Exception e) { e.printStackTrace ();
		} finally { closeAll (); }
		
		return 0;
	}
	
	@Override
	public TalkaboutVO boardSearchByNo (int no) throws SQLException {
		try {
			conn = ds.getConnection ();
			pstmt = conn.prepareStatement ("select * from bookchigi_bbs where bbs_no = ?");
			pstmt.setInt (1, no);
			rset = pstmt.executeQuery ();
			
			if (rset.next ()) return new TalkaboutVO (rset);
		} catch (Exception e) { e.printStackTrace ();
		} finally { closeAll (); }
		
		return null;
	}
	
	@Override
	public List<TalkaboutVO> boardPaging (int no) throws SQLException {
		List<TalkaboutVO> list = new ArrayList<TalkaboutVO> ();
		
		try {
			conn = ds.getConnection ();
			pstmt = conn.prepareStatement ("select * from bookchigi_bbs "
					+ "where (rownum between ? and ?) and (bbs_reference = -1) and (bbs_no > 0) order by bbs_no desc");
			pstmt.setInt (1, (no - 1) * 20 + 1);
			pstmt.setInt (2, no * 20);
			rset = pstmt.executeQuery ();
			
			while (rset.next ()) list.add (new TalkaboutVO (rset));
			
			return list;
		} catch (Exception e) { e.printStackTrace ();
		} finally { closeAll (); }
		
		return null;
	}

	@Override
	public List<TalkaboutVO> boardSearchByTitle (int pgdx, String title) throws SQLException {
		List<TalkaboutVO> list = new ArrayList<TalkaboutVO> ();
		
		try {
			conn = ds.getConnection ();
			pstmt = conn.prepareStatement ("select * from (select * from bookchigi_bbs where title on ?) "
					+ "where (rownum between ? and ?) and (bbs_reference = -1) and (bbs_no > 0) order by bbs_no desc");
			pstmt.setString (1, title);
			pstmt.setInt (2, (pgdx - 1) * 20 + 1);
			pstmt.setInt (3, pgdx * 20);
			rset = pstmt.executeQuery ();
			
			while (rset.next ()) list.add (new TalkaboutVO (rset));
			
			return list;
		} catch (Exception e) { e.printStackTrace ();
		} finally { closeAll (); }
		
		return null;
	}

	@Override
	public List<TalkaboutVO> boardSearchByWriter (int pgdx, String writer) throws SQLException {
		List<TalkaboutVO> list = new ArrayList<TalkaboutVO> ();
		
		try {
			conn = ds.getConnection ();
			pstmt = conn.prepareStatement ("select * from (select * from bookchigi_bbs where writer on ?) "
					+ "where (rownum between ? and ?) and (bbs_reference = -1) and (bbs_no > 0) order by bbs_no desc");
			pstmt.setString (1, writer);
			pstmt.setInt (2, (pgdx - 1) * 20 + 1);
			pstmt.setInt (3, pgdx * 20);
			rset = pstmt.executeQuery ();
			
			while (rset.next ()) list.add (new TalkaboutVO (rset));
			
			return list;
		} catch (Exception e) { e.printStackTrace ();
		} finally { closeAll (); }
		
		return null;
	}

	@Override
	public List<TalkaboutVO> boardSearchByContent (int pgdx, String keyword) throws SQLException {
		List<TalkaboutVO> list = new ArrayList<TalkaboutVO> ();
		
		try {
			conn = ds.getConnection ();
			pstmt = conn.prepareStatement ("select * from (select * from bookchigi_bbs where keyword on ?) "
					+ "where (rownum between ? and ?) and (bbs_reference = -1) and (bbs_no > 0) order by bbs_no desc");
			pstmt.setString (1, keyword);
			pstmt.setInt (2, (pgdx - 1) * 20 + 1);
			pstmt.setInt (3, pgdx * 20);
			rset = pstmt.executeQuery ();
			
			while (rset.next ()) list.add (new TalkaboutVO (rset));
			
			return list;
		} catch (Exception e) { e.printStackTrace ();
		} finally { closeAll (); }
		
		return null;
	}

	@Override
	public int report (TalkaboutVO talkaboutVO) throws SQLException {
		try {
			conn = ds.getConnection ();
			pstmt = conn.prepareStatement ("update bookchigi_bbs set bbs_viewcount = -1 * abs(bbs_viewcount) where bbs_no = ?");
			pstmt.setInt (1, talkaboutVO.getTalkaboutNo ());
			return pstmt.executeUpdate ();
		} catch (Exception e) { e.printStackTrace ();
		} finally { closeAll (); }
		
		return 0;
	}
}