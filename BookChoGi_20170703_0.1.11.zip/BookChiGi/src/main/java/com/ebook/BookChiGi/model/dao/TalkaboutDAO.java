package com.ebook.BookChiGi.model.dao;

import java.sql.SQLException;
import java.util.List;

import com.ebook.BookChiGi.model.dto.TalkaboutVO;

public interface TalkaboutDAO {
	int boardWrite (TalkaboutVO talkaboutVO) throws SQLException;
	int boardUpdate (TalkaboutVO talkaboutVO) throws SQLException;
	int boardDelete (int no) throws SQLException;
	int boardCount (int reference) throws SQLException;
	int boardViewed (int no) throws SQLException;
	TalkaboutVO boardSearchByNo (int no) throws SQLException;
	List<TalkaboutVO> boardPaging (int pgdx) throws SQLException;
	List<TalkaboutVO> boardSearchByTitle (int pgdx, String title) throws SQLException;
	List<TalkaboutVO> boardSearchByWriter (int pgdx, String writer) throws SQLException;
	List<TalkaboutVO> boardSearchByContent (int pgdx, String keyword) throws SQLException;
	List<TalkaboutVO> boardSearchByReference (int reference) throws SQLException;
	
	int report (TalkaboutVO talkaboutVO) throws SQLException;
}