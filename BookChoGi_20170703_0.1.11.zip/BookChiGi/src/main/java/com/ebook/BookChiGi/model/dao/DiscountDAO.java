package com.ebook.BookChiGi.model.dao;

import java.sql.SQLException;
import java.util.Map;

import com.ebook.BookChiGi.model.dto.DiscountVO;

public interface DiscountDAO {
	Map<Integer, DiscountVO> discountMap () throws SQLException;
}