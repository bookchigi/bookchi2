package com.ebook.BookChiGi;


import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ebook.BookChiGi.model.dao.BookDAO;
import com.ebook.BookChiGi.model.dao.DiscountDAO;
import com.ebook.BookChiGi.model.dao.MemberDAO;
import com.ebook.BookChiGi.model.dao.TalkaboutDAO;
import com.ebook.BookChiGi.model.dto.MemberVO;
import com.ebook.BookChiGi.model.dto.TalkaboutVO;

/**
 * URL�� �ּҿ� ���� JSP ���� Ŭ����. �ۼ������� Ȩ - �α��� - ȸ������ - ��ÿ��� - ��ȸ���� ��.
 * 
 * @author PurplelightFullmoon
 */
@Controller
public class HomeController {
	private MemberDAO memberDao;
	private BookDAO bookDao;
	private DiscountDAO discountDao;
	private TalkaboutDAO talkaboutDao;
	
	@Autowired public void setMemberDao (MemberDAO memberDao) { this.memberDao = memberDao; }
	@Autowired public void setBookDao (BookDAO bookDao) { this.bookDao = bookDao; }
	@Autowired public void setDiscountDao (DiscountDAO discountDao) { this.discountDao = discountDao; }
	@Autowired public void setTalkaboutDao (TalkaboutDAO talkaboutDao) { this.talkaboutDao = talkaboutDao; }
	
	/*== Ȩ ==*/
	@RequestMapping ("/") public String home (Model model) {
		try { model.addAttribute ("booklist_new", bookDao.alignBookByNew (1)); } catch (SQLException e) { e.printStackTrace (); }
		try { model.addAttribute ("booklist_pop", bookDao.alignBookByPop (1)); } catch (SQLException e) { e.printStackTrace (); }
		try { model.addAttribute ("booklist_rec", bookDao.alignBookByRec (1)); } catch (SQLException e) { e.printStackTrace (); }
		try { model.addAttribute ("booklist_sec", bookDao.alignBookBySec (1)); } catch (SQLException e) { e.printStackTrace (); }
		
		return "home";
	}
	
	/*== �α��� ==*/
	@RequestMapping (value="/login", method=RequestMethod.GET) public String login (HttpSession session, Model model) {
		if (session.getAttribute("account") != null) {
			session.removeAttribute ("account");
			
			try { model.addAttribute ("booklist_new", bookDao.alignBookByNew (1)); } catch (SQLException e) { e.printStackTrace (); }
			try { model.addAttribute ("booklist_pop", bookDao.alignBookByPop (1)); } catch (SQLException e) { e.printStackTrace (); }
			try { model.addAttribute ("booklist_rec", bookDao.alignBookByRec (1)); } catch (SQLException e) { e.printStackTrace (); }
			try { model.addAttribute ("booklist_sec", bookDao.alignBookBySec (1)); } catch (SQLException e) { e.printStackTrace (); }
			
			return "home";
		}
		
		return "login";
	}
	@RequestMapping (value="/login", method=RequestMethod.POST) public ModelAndView login (@ModelAttribute MemberVO member, Model model, HttpSession session) {
		ModelAndView mav = new ModelAndView ();
		
		try {
			if (memberDao.isLoginPassed (member.getUserMail (), member.getUserPw ())) {
				session.setAttribute ("account", memberDao.searchMemberByMail (member.getUserMail ()));
				try { model.addAttribute ("booklist_new", bookDao.alignBookByNew (1)); } catch (SQLException e) { e.printStackTrace (); }
				try { model.addAttribute ("booklist_pop", bookDao.alignBookByPop (1)); } catch (SQLException e) { e.printStackTrace (); }
				try { model.addAttribute ("booklist_rec", bookDao.alignBookByRec (1)); } catch (SQLException e) { e.printStackTrace (); }
				try { model.addAttribute ("booklist_sec", bookDao.alignBookBySec (1)); } catch (SQLException e) { e.printStackTrace (); }
				
				try { model.addAttribute ("discountMap", discountDao.discountMap ()); } catch (SQLException e) { e.printStackTrace (); }
				
				mav.setViewName ("home");
				return mav;
			} else {
				mav.addObject ("loginErr", "<div class='alert alert-danger' role='alert'>�α��ο� �����Ͽ����ϴ�. �ٽ� �α������ּ���.</div><br>");
				
				mav.setViewName ("login");
				return mav;
			}
		} catch (Exception e) {
			e.printStackTrace ();
			mav.addObject ("loginErr", "<div class='alert alert-danger' role='alert'>�α��� �߿� ������ �߻��� �� �մϴ�. �ٽ� �α������ּ���.</div><br>");
			
			mav.setViewName ("login");
			return mav;
		}
	}
	
	/*== ȸ������ ==*/
	@RequestMapping (value="/signup", method=RequestMethod.GET) public String signup () { return "signup"; }
	@RequestMapping (value="/signup", method=RequestMethod.POST) public String signup (@ModelAttribute MemberVO member, Model model) {
		int result = 0;
		String errMsg = "";

		if (!member.getUserPw().equals (member.getRepeatPw ())) {
			errMsg = "��Ͽ� �����߽��ϴ�. �н����� Ȯ���� ��ġ���� �ʽ��ϴ�.";
			model.addAttribute ("signupErr", "<div class='alert alert-danger' role='alert'>" + errMsg + "</div>");
			System.out.println (errMsg);
			return "redirect:signup";
		}
		
		try {
			result = memberDao.signupMember (member);
		} catch (SQLException e) { e.printStackTrace (); }
		
		if (result == 1) return "signupok";
		else {
			switch (result) {
				case -1 : errMsg = "��Ͽ� �����߽��ϴ�. �� ������ �ݺ��� ��� �����ּ� �ߺ��� ���ɼ��� �����ϴ�."; break;
				case  0 : errMsg = "��Ͽ� �����߽��ϴ�. �� ������ �ݺ��� ��� �����ڿ��� �����Ͽ��ּ���."; break;
				default : break;
			}
			
			System.out.println (errMsg);
			model.addAttribute ("signupErr", "<div class='alert alert-danger' role='alert'>" + errMsg + "</div>");
			
			return "redirect:signup";
		}
	}
	
	/*== ��ÿ��� ==*/
	@RequestMapping (value="/myaccount", method=RequestMethod.GET) public String myaccount () { return "myaccount"; }
	@RequestMapping ("/recentBook") public String recentBook () { return "recentBook"; }
	@RequestMapping ("/favorite") public String favorite () { return "favorite"; }
	@RequestMapping ("/purchased") public String purchased () { return "purchased"; }
	@RequestMapping ("/secondary") public String secondary () { return "secondary"; }
	@RequestMapping (value="/writetalk", method=RequestMethod.GET) public String writeTalk () { return "writetalk"; }
	
	/*== ��ȸ���� ==*/
	@RequestMapping (value="/myaccount", method=RequestMethod.POST) public ModelAndView myaccount (@ModelAttribute MemberVO member, HttpSession session) {
		int result = 0;
		ModelAndView mav = new ModelAndView ();
		
		if (session.getAttribute ("account") != null) {
			try {
				result = memberDao.modifyMember (member);
				if (result != 0) {
					mav.setViewName ("redirect:/");
					session.setAttribute ("account", member);
				} else {
					mav.setViewName ("myaccount");
					mav.addObject ("myaccountErr", "<div class='alert alert-danger' role='alert'>���� ������ ����� ���� ���� ����̿���... "
							+ "�ٽ� �ѹ� �� �������ֽðھ��?</div>");
				}
			} catch (SQLException e) {
				e.printStackTrace ();
				mav.setViewName ("myaccount");
				mav.addObject ("myaccountErr", "<div class='alert alert-danger' role='alert'>��񸸿�... �ٽ� �ѹ� �� �������ֽðھ��?</div>");
			}
			
			return mav;
		}
		
		mav.setViewName ("myaccount");
		return mav;
	}
	
	@RequestMapping (value="/detail/{idx}", method=RequestMethod.GET) public String detail (@PathVariable int idx, Model model) {
		try { model.addAttribute ("book", bookDao.searchBookByIsbn (idx)); } catch (Exception e) { e.printStackTrace (); }
		
		return "detail";
	}

	@RequestMapping ("/talkabout") public ModelAndView talkabout (HttpServletRequest request) {
		ModelAndView mav = new ModelAndView ();
		int pgPtr = 1;
		int pgMin = 1;
		int pgMax = 1;
		int pgCnt = 1;
		
		try {
			if (request.getParameter ("pgdx") != null) {
				if (request.getParameter ("no") != null)
					mav.addObject ("list", talkaboutDao.boardSearchByNo (Integer.parseInt (request.getParameter ("no"))));
				else if (request.getParameter ("writer") != null)
					mav.addObject ("list", talkaboutDao.boardSearchByWriter (Integer.parseInt (request.getParameter ("pgdx")), request.getParameter ("writer")));
				else if (request.getParameter ("title") != null)
					mav.addObject ("list", talkaboutDao.boardSearchByTitle (Integer.parseInt (request.getParameter ("pgdx")), request.getParameter ("title")));
				else if (request.getParameter ("content") != null)
					mav.addObject ("list", talkaboutDao.boardSearchByContent (Integer.parseInt (request.getParameter ("pgdx")), request.getParameter ("content")));
				else mav.addObject ("list", talkaboutDao.boardPaging (Integer.parseInt (request.getParameter ("pgdx"))));
			} else {
				if (request.getParameter ("no") != null)
					mav.addObject ("list", talkaboutDao.boardSearchByNo (Integer.parseInt (request.getParameter ("no"))));
				else if (request.getParameter ("writer") != null)
					mav.addObject ("list", talkaboutDao.boardSearchByWriter (1, request.getParameter ("writer")));
				else if (request.getParameter ("title") != null)
					mav.addObject ("list", talkaboutDao.boardSearchByTitle (1, request.getParameter ("title")));
				else if (request.getParameter ("content") != null)
					mav.addObject ("list", talkaboutDao.boardSearchByContent (1, request.getParameter ("content")));
				else mav.addObject ("list", talkaboutDao.boardPaging (1));
			}

		} catch (Exception e) {
			e.printStackTrace ();
			mav.setViewName ("error");
		}
		
		try { pgPtr = Integer.parseInt (request.getParameter("pgdx")); } catch (Exception e) {}
		try { pgCnt = talkaboutDao.boardCount (-1); } catch (Exception e) { e.printStackTrace (); }
		pgMin = pgPtr - 2 < 1? 1 : pgPtr - 2;
		pgMax = pgPtr + 2 > pgCnt? pgCnt : pgPtr + 2;
		ArrayList<Integer> paginator = new ArrayList<Integer> ();
		for (int count=pgMin ; count<=pgMax ; count++) paginator.add (count);
		mav.addObject ("paginator", paginator);
		mav.addObject ("pgdx", request.getParameter ("pgdx"));
		
		return mav;
	}
	
	@RequestMapping (value="/writetalk", method=RequestMethod.POST) public ModelAndView talkabout (@ModelAttribute TalkaboutVO talkabout, HttpSession session) {
		ModelAndView mav = new ModelAndView ();
		
		try {
			if (session.getAttribute ("account") != null) {
				talkaboutDao.boardWrite (talkabout);
				
				mav.setViewName ("redirect:/talkabout");
			} else mav.setViewName ("error");
		} catch (Exception e) {}
		
		return mav;
	}
	
	@RequestMapping (value="/talkabout/{pid}", method=RequestMethod.GET) public ModelAndView talkpage (@PathVariable int pid) {
		ModelAndView mav = new ModelAndView ();
		
		try {
			talkaboutDao.boardViewed (pid);
			mav.addObject ("talkabout", talkaboutDao.boardSearchByNo (pid));
			mav.addObject ("reply", talkaboutDao.boardSearchByReference (pid));
			mav.setViewName ("talkaboutpage");
		} catch (Exception e) {
			e.printStackTrace ();
			mav.setViewName ("error");
		}
		
		return mav;
	}
	
	@RequestMapping (value="/talkabout/{pid}", method=RequestMethod.POST) public ModelAndView talkpage (@PathVariable int pid, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView ();
		
		try {
			if (talkaboutDao.boardWrite (new TalkaboutVO (0, request.getParameter("talkaboutWriter"), request.getParameter ("talkaboutTitle"),
					request.getParameter("talkaboutContent"), null, 0, Integer.parseInt (request.getParameter ("talkaboutReference")))) != 0) {
				mav.addObject ("talkabout", talkaboutDao.boardSearchByNo (pid));
				mav.setViewName ("redirect:/talkabout/" + pid);
			} else mav.setViewName ("error");
		} catch (Exception e) {
			e.printStackTrace ();
			mav.setViewName ("error");
		}
		
		return mav;
	}
	
	@RequestMapping (value="/talkabout/edit/{pid}", method=RequestMethod.GET) public ModelAndView talkedit (@PathVariable int pid) {
		ModelAndView mav = new ModelAndView ();
		
		try {
			mav.addObject ("talkabout", talkaboutDao.boardSearchByNo (pid));
			mav.setViewName ("writetalkedit");
		} catch (Exception e) {
			e.printStackTrace ();
			mav.setViewName ("error");
		}
		
		return mav;
	}
	
	@RequestMapping (value="/talkabout/edit/{pid}", method=RequestMethod.POST) public ModelAndView talkedit (@ModelAttribute TalkaboutVO talkabout, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView ();
		
		try {
			if (talkaboutDao.boardUpdate (talkabout) != 0) {
				mav.addObject ("talkabout", talkaboutDao.boardSearchByNo (talkabout.getTalkaboutNo ()));
				mav.setViewName ("redirect:/talkabout/" + talkabout.getTalkaboutNo ());
			} else mav.setViewName ("error");
		} catch (Exception e) {
			e.printStackTrace ();
			mav.setViewName ("error");
		}
		
		return mav;
	}
	
	@RequestMapping ("/talkabout/delete/{pid}") public ModelAndView talkdelete (@PathVariable int pid, HttpSession session) {
		ModelAndView mav = new ModelAndView ();
		
		try {
			if (session.getAttribute ("account") != null) {
				if (talkaboutDao.boardDelete (pid) != 0) mav.setViewName ("redirect:/talkabout");
				else mav.setViewName ("error");
			} else mav.setViewName ("error");
		} catch (Exception e) {
			e.printStackTrace ();
			mav.setViewName ("error");
		}
		
		return mav;
	}
}