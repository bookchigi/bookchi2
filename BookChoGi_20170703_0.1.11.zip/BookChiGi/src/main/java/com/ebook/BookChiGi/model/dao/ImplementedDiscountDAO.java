package com.ebook.BookChiGi.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;

import com.ebook.BookChiGi.model.dto.DiscountVO;

public class ImplementedDiscountDAO implements DiscountDAO {
	@Autowired
	private DataSource ds = null;
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rset = null;
	
	private void closeAll () throws SQLException {
		if (rset != null) rset.close ();
		if (pstmt != null) pstmt.close ();
		if (conn != null) conn.close ();
	}
	
	@Override
	public Map<Integer, DiscountVO> discountMap () throws SQLException {
		Map<Integer, DiscountVO> discountMap = new HashMap<Integer, DiscountVO> ();
		
		try {
			conn = ds.getConnection ();
			pstmt = conn.prepareStatement ("select * from bookchigi_discount");
			rset = pstmt.executeQuery ();
			
			while (rset.next ()) {
				discountMap.put (rset.getInt ("discount_target"), new DiscountVO (rset));
			}
		} catch (Exception e) { e.printStackTrace ();
		} finally { closeAll (); }
		
		return discountMap;
	}
}