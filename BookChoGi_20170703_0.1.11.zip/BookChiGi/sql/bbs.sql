drop sequence bbs_seq;
create sequence bbs_seq start with 0 increment by 1 minvalue 0 maxvalue 999999 nocycle;

drop table bookchigi_bbs;
create table bookchigi_bbs (
    bbs_No number unique,
    bbs_writer varchar2(40) not null,
    bbs_title varchar2(200) not null,
    bbs_content varchar2(1024),
    bbs_date date default sysdate,
    bbs_viewcount number default 0,
    bbs_reference number default -1
);

select * from bookchigi_bbs;
commit;